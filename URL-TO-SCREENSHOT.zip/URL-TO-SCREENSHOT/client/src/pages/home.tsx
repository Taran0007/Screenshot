import { useState } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ScreenshotForm from "@/components/screenshot-form";
import LoadingState from "@/components/loading-state";
import ScreenshotResult from "@/components/screenshot-result";
import FeaturesSection from "@/components/features-section";
import { ScreenshotResponse } from "@shared/schema";

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [screenshotData, setScreenshotData] = useState<ScreenshotResponse | null>(null);
  const [error, setError] = useState<string>("");

  const handleScreenshotCapture = (data: ScreenshotResponse) => {
    setScreenshotData(data);
    setIsLoading(false);
    setError("");
  };

  const handleLoadingStart = () => {
    setIsLoading(true);
    setError("");
    setScreenshotData(null);
  };

  const handleError = (errorMessage: string) => {
    setError(errorMessage);
    setIsLoading(false);
    setScreenshotData(null);
  };

  const handleNewScreenshot = () => {
    setScreenshotData(null);
    setError("");
    setIsLoading(false);
  };

  return (
    <div className="bg-gray-50 font-inter min-h-screen">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        <ScreenshotForm 
          onLoadingStart={handleLoadingStart}
          onSuccess={handleScreenshotCapture}
          onError={handleError}
          error={error}
          isLoading={isLoading}
        />
        
        {isLoading && <LoadingState />}
        
        {screenshotData && (
          <ScreenshotResult 
            data={screenshotData}
            onNewScreenshot={handleNewScreenshot}
          />
        )}
        
        <FeaturesSection />
      </main>
      
      <Footer />
    </div>
  );
}
