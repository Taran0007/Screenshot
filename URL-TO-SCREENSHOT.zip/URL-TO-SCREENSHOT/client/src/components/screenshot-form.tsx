import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Camera, Globe, Loader2, AlertTriangle, Settings, Monitor, Smartphone, Tablet, Clock, Image, ChevronDown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { screenshotRequestSchema, type ScreenshotResponse, type ScreenshotRequest } from "@shared/schema";
import LoadingModal from "./loading-modal";

interface ScreenshotFormProps {
  onLoadingStart: () => void;
  onSuccess: (data: ScreenshotResponse) => void;
  onError: (error: string) => void;
  error: string;
  isLoading: boolean;
}

export default function ScreenshotForm({ onLoadingStart, onSuccess, onError, error, isLoading }: ScreenshotFormProps) {
  const [url, setUrl] = useState("");
  const [inputStatus, setInputStatus] = useState<"default" | "valid" | "invalid">("default");
  const [format, setFormat] = useState<"png" | "jpeg" | "webp">("png");
  const [viewportMode, setViewportMode] = useState<"desktop" | "mobile" | "tablet" | "custom">("desktop");
  const [width, setWidth] = useState(1920);
  const [height, setHeight] = useState(1080);
  const [fullPage, setFullPage] = useState(true);
  const [delay, setDelay] = useState(2);
  const [quality, setQuality] = useState(90);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showLoadingModal, setShowLoadingModal] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);

  const validateUrl = (value: string) => {
    if (!value.trim()) {
      setInputStatus("default");
      return;
    }

    try {
      screenshotRequestSchema.parse({ url: value });
      setInputStatus("valid");
    } catch {
      setInputStatus("invalid");
    }
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setUrl(value);
    validateUrl(value);
    if (error) {
      onError("");
    }
  };

  const handleViewportModeChange = (mode: "desktop" | "mobile" | "tablet" | "custom") => {
    setViewportMode(mode);
    switch (mode) {
      case "desktop":
        setWidth(1920);
        setHeight(1080);
        break;
      case "mobile":
        setWidth(375);
        setHeight(812);
        break;
      case "tablet":
        setWidth(768);
        setHeight(1024);
        break;
      default:
        break;
    }
  };

  const simulateProgress = () => {
    setLoadingProgress(0);
    const progressInterval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 95) {
          clearInterval(progressInterval);
          return 95;
        }
        return prev + Math.random() * 10;
      });
    }, 500);
    return progressInterval;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const requestData: ScreenshotRequest = {
        url: url.trim(),
        format,
        viewportMode,
        width,
        height,
        fullPage,
        delay,
        quality: format === 'jpeg' ? quality : undefined
      };

      const validatedData = screenshotRequestSchema.parse(requestData);
      
      onLoadingStart();
      setShowLoadingModal(true);
      
      const progressInterval = simulateProgress();
      
      const response = await apiRequest("POST", "/api/screenshot", validatedData);
      const data = await response.json();
      
      clearInterval(progressInterval);
      setLoadingProgress(100);
      
      setTimeout(() => {
        setShowLoadingModal(false);
        if (data.success) {
          onSuccess(data);
        } else {
          onError(data.message || "Failed to capture screenshot");
        }
      }, 500);
      
    } catch (err: any) {
      setShowLoadingModal(false);
      if (err.issues) {
        onError(err.issues[0].message);
      } else {
        onError("Failed to capture screenshot. Please try again.");
      }
    }
  };

  const getInputClasses = () => {
    const base = "w-full px-4 py-3 pl-12 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200 text-lg";
    
    switch (inputStatus) {
      case "valid":
        return `${base} border-green-300 bg-green-50`;
      case "invalid":
        return `${base} border-red-300 bg-red-50`;
      default:
        return `${base} border-gray-300`;
    }
  };

  const getViewportIcon = (mode: string) => {
    switch (mode) {
      case "mobile": return <Smartphone className="w-4 h-4" />;
      case "tablet": return <Tablet className="w-4 h-4" />;
      case "desktop": return <Monitor className="w-4 h-4" />;
      default: return <Settings className="w-4 h-4" />;
    }
  };

  return (
    <>
      <Card className="rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 sm:p-8 mb-8 bg-white dark:bg-gray-800">
        <CardHeader className="p-0 mb-6">
          <div className="text-center">
            <CardTitle className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-2">
              Website Screenshot Tool
            </CardTitle>
            <p className="text-gray-600 dark:text-gray-300">Capture high-quality screenshots with advanced options</p>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* URL Input */}
            <div className="space-y-2">
              <Label htmlFor="url" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Website URL *
              </Label>
              <div className="relative">
                <input
                  type="url"
                  id="url"
                  name="url"
                  value={url}
                  onChange={handleUrlChange}
                  placeholder="https://example.com"
                  className={getInputClasses()}
                  required
                  disabled={isLoading}
                />
                <Globe className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              </div>
              {error && (
                <Alert className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20">
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                  <AlertDescription className="text-red-700 dark:text-red-400">
                    {error}
                  </AlertDescription>
                </Alert>
              )}
            </div>

            {/* Quick Options */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="space-y-2">
                <Label className="text-xs font-medium text-gray-600 dark:text-gray-400">Format</Label>
                <Select value={format} onValueChange={(value: "png" | "jpeg" | "webp") => setFormat(value)}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="png">PNG</SelectItem>
                    <SelectItem value="jpeg">JPEG</SelectItem>
                    <SelectItem value="webp">WebP</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-medium text-gray-600 dark:text-gray-400">Device</Label>
                <Select value={viewportMode} onValueChange={handleViewportModeChange}>
                  <SelectTrigger className="h-9">
                    <div className="flex items-center gap-2">
                      {getViewportIcon(viewportMode)}
                      <SelectValue />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="desktop">Desktop</SelectItem>
                    <SelectItem value="mobile">Mobile</SelectItem>
                    <SelectItem value="tablet">Tablet</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-medium text-gray-600 dark:text-gray-400">Delay</Label>
                <Select value={delay.toString()} onValueChange={(value) => setDelay(parseInt(value))}>
                  <SelectTrigger className="h-9">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      <SelectValue />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">No delay</SelectItem>
                    <SelectItem value="2">2 seconds</SelectItem>
                    <SelectItem value="5">5 seconds</SelectItem>
                    <SelectItem value="10">10 seconds</SelectItem>
                    <SelectItem value="15">15 seconds</SelectItem>
                    <SelectItem value="30">30 seconds</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-medium text-gray-600 dark:text-gray-400">Mode</Label>
                <div className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 rounded-md px-3 py-2 h-9">
                  <span className="text-sm">{fullPage ? "Full page" : "Viewport"}</span>
                  <Switch
                    checked={fullPage}
                    onCheckedChange={setFullPage}
                  />
                </div>
              </div>
            </div>

            {/* Advanced Options */}
            <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                  <div className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                    <Settings className="w-4 h-4" />
                    Advanced Options
                  </div>
                  <ChevronDown className={`w-4 h-4 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
                </Button>
              </CollapsibleTrigger>
              
              <CollapsibleContent className="space-y-4 mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                {/* Custom Dimensions */}
                {viewportMode === "custom" && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Width: {width}px</Label>
                      <Slider
                        value={[width]}
                        onValueChange={(value) => setWidth(value[0])}
                        max={3840}
                        min={320}
                        step={10}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Height: {height}px</Label>
                      <Slider
                        value={[height]}
                        onValueChange={(value) => setHeight(value[0])}
                        max={2160}
                        min={240}
                        step={10}
                        className="w-full"
                      />
                    </div>
                  </div>
                )}

                {/* Quality for JPEG/WebP */}
                {(format === "jpeg" || format === "webp") && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Quality: {quality}%</Label>
                    <Slider
                      value={[quality]}
                      onValueChange={(value) => setQuality(value[0])}
                      max={100}
                      min={10}
                      step={5}
                      className="w-full"
                    />
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-gray-600 dark:text-gray-400">
                  <div className="space-y-1">
                    <p><strong>Resolution:</strong> {width} × {height}px</p>
                    <p><strong>Format:</strong> {format.toUpperCase()}</p>
                  </div>
                  <div className="space-y-1">
                    <p><strong>Capture:</strong> {fullPage ? "Full page" : "Viewport only"}</p>
                    <p><strong>Wait time:</strong> {delay}s</p>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full font-semibold py-4 px-6 rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
              disabled={isLoading || inputStatus === "invalid" || !url.trim()}
              size="lg"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Capturing...
                </>
              ) : (
                <>
                  <Camera className="mr-2 h-5 w-5" />
                  Capture Screenshot
                </>
              )}
            </Button>

            {/* Features List */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-gray-500 dark:text-gray-400 pt-2">
              <div className="flex items-center gap-1">
                <Image className="w-3 h-3" />
                <span>High quality</span>
              </div>
              <div className="flex items-center gap-1">
                <Monitor className="w-3 h-3" />
                <span>Multiple devices</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Custom timing</span>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      <LoadingModal 
        isOpen={showLoadingModal}
        onClose={() => setShowLoadingModal(false)}
        url={url}
        progress={loadingProgress}
      />
    </>
  );
}
