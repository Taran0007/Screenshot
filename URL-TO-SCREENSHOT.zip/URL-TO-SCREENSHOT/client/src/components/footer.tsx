import { Code } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 mt-16">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-center text-gray-600">
          <p className="mb-2">
            <Code className="inline text-gray-400 mr-2 w-4 h-4" />
            Built with Node.js, Express, and Puppeteer
          </p>
          <p className="text-sm">
            Free and open source • No registration required • Instant results
          </p>
        </div>
      </div>
    </footer>
  );
}
