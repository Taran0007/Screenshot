import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Check, Download, Plus, Image, FileImage, Info, Loader2 } from "lucide-react";
import { ScreenshotResponse } from "@shared/schema";

interface ScreenshotResultProps {
  data: ScreenshotResponse;
  onNewScreenshot: () => void;
}

export default function ScreenshotResult({ data, onNewScreenshot }: ScreenshotResultProps) {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);

  const handleDownload = async () => {
    setIsDownloading(true);
    
    try {
      const response = await fetch(data.downloadUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = data.filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      setDownloadComplete(true);
      setTimeout(() => {
        setDownloadComplete(false);
      }, 2000);
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleNewScreenshot = () => {
    onNewScreenshot();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <Card className="rounded-xl shadow-lg border border-gray-200 p-8">
      <CardContent className="p-0">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
            <Check className="text-green-500 w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">Screenshot Captured Successfully!</h3>
          <p className="text-gray-600">Full-page screenshot is ready for viewing and download</p>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Image className="text-gray-500 mr-2 w-4 h-4" />
              <span className="text-sm font-medium text-gray-700">{data.filename}</span>
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <FileImage className="mr-1 w-4 h-4" />
              <span>{data.fileSize}</span>
              <span className="mx-2">•</span>
              <span>{data.dimensions}</span>
            </div>
          </div>
          
          <div className="relative bg-white rounded-lg border-2 border-gray-200 overflow-hidden shadow-inner">
            <img 
              src={data.downloadUrl}
              alt="Website screenshot preview" 
              className="w-full h-auto max-h-96 object-contain"
            />
            
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/50 to-transparent p-4">
              <p className="text-white text-sm text-center">
                <Info className="inline mr-1 w-4 h-4" />
                Full-page screenshot captured at original resolution
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <Button 
            onClick={handleDownload}
            disabled={isDownloading}
            className="flex-1 bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl"
          >
            {isDownloading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Downloading...
              </>
            ) : downloadComplete ? (
              <>
                <Check className="mr-2 h-5 w-5" />
                Downloaded!
              </>
            ) : (
              <>
                <Download className="mr-2 h-5 w-5" />
                Download Screenshot
              </>
            )}
          </Button>
          
          <Button 
            onClick={handleNewScreenshot}
            className="flex-1 bg-gray-500 hover:bg-gray-600 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl"
          >
            <Plus className="mr-2 h-5 w-5" />
            New Screenshot
          </Button>
        </div>

        <Alert className="mt-6 border-blue-200 bg-blue-50">
          <Info className="h-4 w-4 text-blue-500" />
          <AlertDescription className="text-blue-700">
            <p className="font-medium mb-1">Screenshot Details:</p>
            <ul className="space-y-1 text-blue-600 text-sm">
              <li>• Full-page capture including content below the fold</li>
              <li>• High-resolution PNG format for crisp quality</li>
              <li>• Captured at desktop viewport (1920px width)</li>
              <li>• Mobile-responsive elements included</li>
            </ul>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
