import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Camera, Monitor, Smartphone, Tablet, Clock, Image, CheckCircle } from "lucide-react";

interface LoadingModalProps {
  isOpen: boolean;
  onClose: () => void;
  url: string;
  progress: number;
}

export default function LoadingModal({ isOpen, onClose, url, progress }: LoadingModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [animatedProgress, setAnimatedProgress] = useState(0);

  const steps = [
    { icon: CheckCircle, label: "Validating URL", color: "text-blue-500" },
    { icon: Monitor, label: "Launching Browser", color: "text-green-500" },
    { icon: Image, label: "Loading Website", color: "text-purple-500" },
    { icon: Camera, label: "Capturing Screenshot", color: "text-orange-500" },
    { icon: CheckCircle, label: "Processing Image", color: "text-emerald-500" },
  ];

  useEffect(() => {
    if (isOpen) {
      setCurrentStep(0);
      setAnimatedProgress(0);
    }
  }, [isOpen]);

  useEffect(() => {
    const timer = setInterval(() => {
      setAnimatedProgress(prev => {
        const target = progress;
        const diff = target - prev;
        return prev + Math.min(diff * 0.1, 2);
      });
    }, 50);

    return () => clearInterval(timer);
  }, [progress]);

  useEffect(() => {
    if (animatedProgress >= 20 && currentStep < 1) setCurrentStep(1);
    if (animatedProgress >= 40 && currentStep < 2) setCurrentStep(2);
    if (animatedProgress >= 60 && currentStep < 3) setCurrentStep(3);
    if (animatedProgress >= 80 && currentStep < 4) setCurrentStep(4);
  }, [animatedProgress, currentStep]);

  const getDomainFromUrl = (url: string) => {
    try {
      return new URL(url).hostname;
    } catch {
      return url;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md border-0 bg-white dark:bg-gray-900 shadow-2xl">
        <div className="flex flex-col items-center space-y-6 p-6">
          {/* Animated Camera Icon */}
          <div className="relative">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center animate-pulse">
              <Camera className="w-10 h-10 text-white animate-bounce" />
            </div>
            <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center animate-ping">
              <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
          </div>

          {/* Title and URL */}
          <div className="text-center">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Capturing Screenshot
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 break-all">
              {getDomainFromUrl(url)}
            </p>
          </div>

          {/* Progress Bar */}
          <div className="w-full space-y-2">
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
              <span>Progress</span>
              <span>{Math.round(animatedProgress)}%</span>
            </div>
            <Progress value={animatedProgress} className="h-2" />
          </div>

          {/* Steps */}
          <div className="w-full space-y-3">
            {steps.map((step, index) => {
              const StepIcon = step.icon;
              const isActive = index <= currentStep;
              const isCompleted = index < currentStep;
              
              return (
                <div
                  key={index}
                  className={`flex items-center space-x-3 p-2 rounded-lg transition-all duration-300 ${
                    isActive 
                      ? 'bg-blue-50 dark:bg-blue-900/20 scale-105' 
                      : 'bg-gray-50 dark:bg-gray-800/50'
                  }`}
                >
                  <div className={`p-2 rounded-full transition-all duration-300 ${
                    isCompleted 
                      ? 'bg-green-100 dark:bg-green-900/30' 
                      : isActive 
                        ? 'bg-blue-100 dark:bg-blue-900/30' 
                        : 'bg-gray-100 dark:bg-gray-700'
                  }`}>
                    <StepIcon className={`w-4 h-4 transition-all duration-300 ${
                      isCompleted 
                        ? 'text-green-600 dark:text-green-400' 
                        : isActive 
                          ? step.color 
                          : 'text-gray-400'
                    }`} />
                  </div>
                  <span className={`text-sm font-medium transition-all duration-300 ${
                    isActive 
                      ? 'text-gray-900 dark:text-white' 
                      : 'text-gray-500 dark:text-gray-400'
                  }`}>
                    {step.label}
                  </span>
                  {isActive && !isCompleted && (
                    <div className="ml-auto">
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    </div>
                  )}
                  {isCompleted && (
                    <div className="ml-auto">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Loading Animation */}
          <div className="flex space-x-1">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.1}s` }}
              ></div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}