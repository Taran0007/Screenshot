import { Card, CardContent } from "@/components/ui/card";
import { Camera, Check, Loader2, Download } from "lucide-react";

export default function LoadingState() {
  return (
    <Card className="rounded-xl shadow-lg border border-gray-200 p-8 mb-8">
      <CardContent className="p-0">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
            <Camera className="text-blue-500 w-8 h-8 animate-pulse" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">Capturing Screenshot</h3>
          <p className="text-gray-600 mb-6">Please wait while we load and capture the webpage...</p>
          
          <div className="max-w-md mx-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm">
                  <Check className="w-4 h-4" />
                </div>
                <span className="ml-2 text-sm text-gray-700">URL Validated</span>
              </div>
              <div className="flex-1 h-0.5 bg-blue-200 mx-4"></div>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm">
                  <Loader2 className="w-4 h-4 animate-spin" />
                </div>
                <span className="ml-2 text-sm text-gray-700">Loading Page</span>
              </div>
              <div className="flex-1 h-0.5 bg-gray-200 mx-4"></div>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-gray-400 text-sm">
                  <Download className="w-4 h-4" />
                </div>
                <span className="ml-2 text-sm text-gray-400">Ready</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
