import { Card, CardContent } from "@/components/ui/card";
import { Zap, Maximize, Shield } from "lucide-react";

export default function FeaturesSection() {
  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Capture screenshots in seconds with our optimized headless browser",
      color: "bg-blue-100 text-blue-500"
    },
    {
      icon: Maximize,
      title: "Full Page Capture",
      description: "Captures the entire webpage, not just the visible viewport",
      color: "bg-green-100 text-green-500"
    },
    {
      icon: Shield,
      title: "Secure & Private",
      description: "No data storage - screenshots are processed and delivered instantly",
      color: "bg-purple-100 text-purple-500"
    }
  ];

  return (
    <div className="mt-12 grid md:grid-cols-3 gap-6">
      {features.map((feature, index) => (
        <Card key={index} className="rounded-lg shadow-md border border-gray-200 p-6">
          <CardContent className="p-0 text-center">
            <div className={`w-12 h-12 ${feature.color.split(' ')[0]} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <feature.icon className={`${feature.color.split(' ')[1]} w-6 h-6`} />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">{feature.title}</h3>
            <p className="text-gray-600 text-sm">{feature.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
