import type { Express } from "express";
import { createServer, type Server } from "http";
import { screenshotRequestSchema, type ScreenshotRequest, type ScreenshotResponse } from "@shared/schema";
import { z } from "zod";
import puppeteer from "puppeteer";
import path from "path";
import fs from "fs/promises";
import { nanoid } from "nanoid";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Screenshot capture endpoint
  app.post("/api/screenshot", async (req, res) => {
    try {
      // Validate request body
      const validatedData: ScreenshotRequest = screenshotRequestSchema.parse(req.body);
      const { 
        url, 
        format = "png", 
        viewportMode = "desktop",
        fullPage = true, 
        width = 1920, 
        height = 1080,
        delay = 2,
        quality = 90
      } = validatedData;

      // Sanitize URL for filename
      const sanitizedUrl = url.replace(/https?:\/\//, '').replace(/[\/\?&#]/g, '-');
      const filename = `${sanitizedUrl}-screenshot-${nanoid(8)}.${format}`;
      
      // Launch Puppeteer with system Chromium
      const browser = await puppeteer.launch({
        headless: true,
        executablePath: '/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium',
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--disable-gpu',
          '--disable-web-security',
          '--disable-features=VizDisplayCompositor'
        ]
      });

      try {
        const page = await browser.newPage();
        
        // Set viewport
        await page.setViewport({ width, height });
        
        // Set user agent to avoid bot detection
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
        
        // Navigate to the URL with timeout
        await page.goto(url, { 
          waitUntil: 'networkidle2',
          timeout: 30000 
        });
        
        // Wait for custom delay
        await new Promise(resolve => setTimeout(resolve, delay * 1000));
        
        // Take screenshot with proper format and quality handling
        const screenshotOptions: any = {
          fullPage,
          type: format === 'webp' ? 'png' : format as 'png' | 'jpeg'
        };
        
        if (format === 'jpeg' || format === 'webp') {
          screenshotOptions.quality = quality;
        }
        
        const screenshotBuffer = await page.screenshot(screenshotOptions);
        
        await browser.close();
        
        // Calculate file size
        const fileSizeBytes = screenshotBuffer.length;
        const fileSizeMB = (fileSizeBytes / (1024 * 1024)).toFixed(1);
        const fileSize = `${fileSizeMB} MB`;
        
        // Get dimensions (this is approximate since we can't easily get actual dimensions)
        const dimensions = fullPage ? `${width}x${height}+` : `${width}x${height}`;
        
        // Create response data
        const responseData: ScreenshotResponse = {
          success: true,
          filename,
          fileSize,
          dimensions,
          url,
          timestamp: new Date().toISOString(),
          downloadUrl: `/api/download/${encodeURIComponent(filename)}`
        };
        
        // Convert screenshot buffer to base64 for database storage
        const buffer = Buffer.isBuffer(screenshotBuffer) ? screenshotBuffer : Buffer.from(screenshotBuffer);
        const base64Data = buffer.toString('base64');
        
        // Store screenshot in database
        await storage.createScreenshot({
          filename,
          originalUrl: url,
          fileSize,
          dimensions,
          format,
          data: base64Data
        });
        
        res.json(responseData);
        
      } catch (pageError) {
        await browser.close();
        throw pageError;
      }
      
    } catch (error: any) {
      console.error('Screenshot capture error:', error);
      
      let errorMessage = "Failed to capture screenshot";
      
      if (error instanceof z.ZodError) {
        errorMessage = error.issues[0].message;
      } else if (error.message?.includes('Navigation timeout')) {
        errorMessage = "Website took too long to load. Please try again.";
      } else if (error.message?.includes('net::ERR_NAME_NOT_RESOLVED')) {
        errorMessage = "Website not found. Please check the URL and try again.";
      } else if (error.message?.includes('net::ERR_CONNECTION_REFUSED')) {
        errorMessage = "Could not connect to the website. Please try again.";
      }
      
      res.status(400).json({
        success: false,
        message: errorMessage
      });
    }
  });
  
  // Download endpoint
  app.get("/api/download/:filename", async (req, res) => {
    try {
      const { filename } = req.params;
      const decodedFilename = decodeURIComponent(filename);
      
      // Get screenshot from database
      const screenshot = await storage.getScreenshot(decodedFilename);
      
      if (!screenshot) {
        return res.status(404).json({
          success: false,
          message: "Screenshot not found or expired"
        });
      }
      
      // Convert base64 back to buffer
      const screenshotBuffer = Buffer.from(screenshot.data, 'base64');
      
      // Set appropriate headers
      const ext = path.extname(decodedFilename).toLowerCase();
      const mimeType = ext === '.png' ? 'image/png' : 'image/jpeg';
      
      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${decodedFilename}"`);
      res.setHeader('Content-Length', screenshotBuffer.length);
      
      res.send(screenshotBuffer);
      
    } catch (error) {
      console.error('Download error:', error);
      res.status(500).json({
        success: false,
        message: "Failed to download screenshot"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
