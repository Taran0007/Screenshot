import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Screenshot request schema for validation
export const screenshotRequestSchema = z.object({
  url: z.string().url("Please enter a valid URL").min(1, "URL is required"),
  format: z.enum(["png", "jpeg", "webp"]).default("png"),
  viewportMode: z.enum(["desktop", "mobile", "tablet", "custom"]).default("desktop"),
  width: z.number().min(320).max(3840).default(1920),
  height: z.number().min(240).max(2160).default(1080),
  fullPage: z.boolean().default(true),
  delay: z.number().min(0).max(30).default(2),
  quality: z.number().min(10).max(100).default(90).optional(),
});

export type ScreenshotRequest = z.infer<typeof screenshotRequestSchema>;

// Screenshot response type
export type ScreenshotResponse = {
  success: boolean;
  filename: string;
  fileSize: string;
  dimensions: string;
  url: string;
  timestamp: string;
  downloadUrl: string;
};

// Screenshots table for storing screenshot metadata and data
export const screenshots = pgTable("screenshots", {
  id: serial("id").primaryKey(),
  filename: varchar("filename", { length: 255 }).notNull(),
  originalUrl: text("original_url").notNull(),
  fileSize: varchar("file_size", { length: 50 }).notNull(),
  dimensions: varchar("dimensions", { length: 50 }).notNull(),
  format: varchar("format", { length: 10 }).notNull().default("png"),
  data: text("data").notNull(), // Base64 encoded image data
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertScreenshotSchema = createInsertSchema(screenshots).pick({
  filename: true,
  originalUrl: true,
  fileSize: true,
  dimensions: true,
  format: true,
  data: true,
});

export type InsertScreenshot = z.infer<typeof insertScreenshotSchema>;
export type Screenshot = typeof screenshots.$inferSelect;

// Keep existing user schema for compatibility
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
